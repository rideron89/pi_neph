#include "GameForms.h"

const _LookupFormByID LookupFormByID = (_LookupFormByID)0x00451DC0;
