#pragma once

void * ScaleformHeap_Allocate(UInt32 size);
void ScaleformHeap_Free(void * ptr);
