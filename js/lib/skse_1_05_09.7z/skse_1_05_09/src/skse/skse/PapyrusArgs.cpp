#include "PapyrusArgs.h"
#include "PapyrusNativeFunctions.h"
#include "PapyrusVM.h"

//// type -> VMValue

template <> void PackValue <void>(VMValue * dst, void * src, VMClassRegistry * registry)
{
	dst->SetNone();
}

template <> void PackValue <UInt32>(VMValue * dst, UInt32 * src, VMClassRegistry * registry)
{
	dst->SetInt(*src);
}

template <> void PackValue <SInt32>(VMValue * dst, SInt32 * src, VMClassRegistry * registry)
{
	dst->SetInt(*src);
}

template <> void PackValue <float>(VMValue * dst, float * src, VMClassRegistry * registry)
{
	dst->SetFloat(*src);
}

template <> void PackValue <bool>(VMValue * dst, bool * src, VMClassRegistry * registry)
{
	dst->SetBool(*src);
}

template <> void PackValue <BSFixedString>(VMValue * dst, BSFixedString * src, VMClassRegistry * registry)
{
	dst->SetString(src->data);
}

void BindID(VMIdentifier ** identifier, void * srcData, VMClassRegistry * registry, IObjectHandlePolicy * handlePolicy, UInt32 typeID)
{
	UInt32	unk = 0;

	VMClassInfo	* classInfo = (*identifier)->m_type;
	if(classInfo)
		classInfo->AddRef();

	if(registry->Unk_0D(&classInfo->name, &unk))
	{
		UInt64	handle = handlePolicy->Create(typeID, srcData);

		if(	handlePolicy->IsType(unk, handle) ||
			(handle == handlePolicy->GetInvalidHandle()))
		{
			CALL_MEMBER_FN(registry->GetObjectBindPolicy(), BindObject)(identifier, handle);
		}
	}

	if(classInfo)
		classInfo->Release();
}

void PackHandle(VMValue * dst, void * src, UInt32 typeID, VMClassRegistry * registry)
{
	dst->SetNone();

	if(!src) return;

	VMClassInfo	* classInfo = NULL;

	// get class info
	if(registry->GetFormClass(typeID, &classInfo))
		if(classInfo)
			classInfo->Release();

	if(!classInfo) return;

	IObjectHandlePolicy	* handlePolicy = registry->GetHandlePolicy();

	UInt64			handle = handlePolicy->Create(typeID, src);
	VMIdentifier	* identifier = NULL;

	// find existing identifier
	if(!registry->Unk_1A(handle, classInfo->name.data, &identifier))
	{
		if(registry->Unk_13(&classInfo->name, &identifier))
		{
			if(identifier)
			{
				BindID(&identifier, src, registry, handlePolicy, typeID);
			}
		}
	}

	// copy the identifier out
	if(identifier)
	{
		VMValue	tempValue;

		tempValue.SetIdentifier(classInfo);

		CALL_MEMBER_FN(dst, Set)(&tempValue);
		dst->SetIdentifier(&identifier);
	}

	// release our reference
	if(identifier)
	{
		if(!identifier->DecrementLock())
		{
			identifier->Destroy();
		}
	}
}

//// VMValue -> type

template <> void UnpackValue <float>(float * dst, VMValue * src, VMClassRegistry * registry)
{
	switch(src->type)
	{
	case VMValue::kType_Int:
		*dst = src->data.i;
		break;

	case VMValue::kType_Float:
		*dst = src->data.f;
		break;

	case VMValue::kType_Bool:
		*dst = src->data.b;
		break;

	default:
		*dst = 0;
		break;
	}
}

template <> void UnpackValue <UInt32>(UInt32 * dst, VMValue * src, VMClassRegistry * registry)
{
	switch(src->type)
	{
	case VMValue::kType_Int:
		*dst = src->data.u;
		break;

	case VMValue::kType_Float:
		*dst = src->data.f;
		break;

	case VMValue::kType_Bool:
		*dst = src->data.b;
		break;

	default:
		*dst = 0;
		break;
	}
}

template <> void UnpackValue <SInt32>(SInt32 * dst, VMValue * src, VMClassRegistry * registry)
{
	switch(src->type)
	{
	case VMValue::kType_Int:
		*dst = src->data.u;
		break;

	case VMValue::kType_Float:
		*dst = src->data.f;
		break;

	case VMValue::kType_Bool:
		*dst = src->data.b;
		break;

	default:
		*dst = 0;
		break;
	}
}

template <> void UnpackValue <bool>(bool * dst, VMValue * src, VMClassRegistry * registry)
{
	switch(src->type)
	{
	case VMValue::kType_Int:
		*dst = src->data.u != 0;
		break;

	case VMValue::kType_Float:
		*dst = src->data.f != 0;
		break;

	case VMValue::kType_Bool:
		*dst = src->data.b;
		break;

	default:
		*dst = 0;
		break;
	}
}

template <> void UnpackValue <BSFixedString>(BSFixedString * dst, VMValue * src, VMClassRegistry * registry)
{
	const char	* data = NULL;

	if(src->type == VMValue::kType_String)
		data = src->data.str;

	CALL_MEMBER_FN(dst, Set)(data);
}

void * UnpackHandle(VMValue * src, VMClassRegistry * registry, UInt32 typeID)
{
	if(!src->IsIdentifier()) return NULL;

	UInt64	handle = src->data.id->GetHandle();

	if(!(*g_objectHandlePolicy)->IsType(typeID, handle)) return NULL;
	if(!(*g_objectHandlePolicy)->Unk_02(handle)) return NULL;

	return (*g_objectHandlePolicy)->Resolve(typeID, handle);
}

//// type -> type ID

template <> UInt32 GetTypeID <void>(VMClassRegistry * registry)
{
	return VMValue::kType_None;
}

template <> UInt32 GetTypeID <UInt32>(VMClassRegistry * registry)
{
	return VMValue::kType_Int;
}

template <> UInt32 GetTypeID <SInt32>(VMClassRegistry * registry)
{
	return VMValue::kType_Int;
}

template <> UInt32 GetTypeID <int>(VMClassRegistry * registry)
{
	return VMValue::kType_Int;
}

template <> UInt32 GetTypeID <float>(VMClassRegistry * registry)
{
	return VMValue::kType_Float;
}

template <> UInt32 GetTypeID <bool>(VMClassRegistry * registry)
{
	return VMValue::kType_Bool;
}

template <> UInt32 GetTypeID <BSFixedString>(VMClassRegistry * registry)
{
	return VMValue::kType_String;
}

UInt32 GetTypeIDFromFormTypeID(UInt32 formTypeID, VMClassRegistry * registry)
{
	UInt32		result = 0;
	VMClassInfo	* info = NULL;

	if(registry->GetFormClass(formTypeID, &info))
	{
		if(info)
		{
			result = (UInt32)info;

			info->Release();	// yes, really
		}
	}

	return result;
}
