#pragma once

void Hooks_Papyrus_Init(void);
void Hooks_Papyrus_Commit(void);
