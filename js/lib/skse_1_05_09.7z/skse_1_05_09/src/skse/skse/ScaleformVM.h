#pragma once

#include "skse/ScaleformTypes.h"
