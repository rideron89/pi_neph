#pragma once

class VMClassRegistry;

namespace papyrusBook
{
	void RegisterFuncs(VMClassRegistry * registry);
};
