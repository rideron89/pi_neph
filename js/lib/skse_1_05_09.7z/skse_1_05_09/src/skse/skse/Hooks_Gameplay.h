#pragma once

void Hooks_Gameplay_EnableForceContainerCategorization(bool enable);

void Hooks_Gameplay_Commit(void);
